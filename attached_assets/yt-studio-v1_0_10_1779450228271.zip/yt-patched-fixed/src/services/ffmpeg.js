'use strict';

// =====================================================================
// Waz Clipper v2.4 — Pillow-rendered title PNG (perfect Bengali shaping)
//
// Approach (after libass/drawtext repeatedly failed Bengali yuktakhar):
//   1. Pillow + libraqm + harfbuzz pre-renders title to PNG
//   2. ffmpeg overlays PNG on top of 9:16 canvas (no shaping at all)
//   3. mic.png also overlaid for speaker bar
//   4. Speaker name also pre-rendered as PNG (same shaping engine)
//   5. Result: zero ○ dotted-circles, perfect conjuncts, every time
// =====================================================================

const FFMPEG_MODULE_VERSION = '2.6.0-robust-seek-killable';

const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const { ffTime } = require('../utils/timestamp');
const { renderTitlePng } = require('./titleRenderer');

// Track running ffmpeg processes per-job so deleteJob can kill them
const RUNNING = new Map();
function trackProc(jobId, proc) {
  if (!jobId) return;
  if (!RUNNING.has(jobId)) RUNNING.set(jobId, new Set());
  RUNNING.get(jobId).add(proc);
  proc.on('close', () => {
    const set = RUNNING.get(jobId);
    if (set) { set.delete(proc); if (!set.size) RUNNING.delete(jobId); }
  });
}
function killJob(jobId) {
  const set = RUNNING.get(jobId);
  if (!set) return 0;
  let n = 0;
  for (const p of set) {
    try { p.kill('SIGKILL'); n++; } catch (_) {}
  }
  RUNNING.delete(jobId);
  return n;
}

const VIDEO_WIDTH  = parseInt(process.env.VIDEO_WIDTH  || '720', 10);
const VIDEO_HEIGHT = parseInt(process.env.VIDEO_HEIGHT || '1280', 10);
const PRESET  = process.env.FFMPEG_PRESET  || 'ultrafast';
const CRF     = process.env.FFMPEG_CRF     || '24';
const THREADS = process.env.FFMPEG_THREADS || '0';

const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const MIC_PNG    = path.join(PUBLIC_DIR, 'mic.png');

async function makeClip({
  input, start, duration, title, speaker,
  titleStyle = 'centered',
  cropMode = 'crop',
  output, workDir, jobLog, jobId,
}) {
  const W = VIDEO_WIDTH;
  const H = VIDEO_HEIGHT;
  const SQ = W;
  const topBandH    = Math.floor((H - SQ) / 2);
  const bottomBandH = H - SQ - topBandH;
  const videoY      = topBandH;
  const speakerBarY = topBandH + SQ;

  // ---------- 1) Pre-render TITLE as PNG ----------
  // Title color depends on style
  let titleFg, titleBg, titleShadow;
  if (titleStyle === 'yellow_box') {
    titleFg     = [0, 0, 0, 255];
    titleBg     = [0, 0, 0, 0];          // transparent — we draw yellow box separately
    titleShadow = null;
  } else if (titleStyle === 'gradient') {
    titleFg     = [255, 231, 90, 255];   // #FFE75A
    titleBg     = [0, 0, 0, 0];
    titleShadow = [0, 0, 0, 200, 2, 2];
  } else {
    titleFg     = [255, 255, 255, 255];
    titleBg     = [0, 0, 0, 0];
    titleShadow = [0, 0, 0, 200, 2, 2];
  }

  // Title canvas size: full top band height, slightly inset width for yellow_box
  const titleCanvasW = (titleStyle === 'yellow_box') ? W - 56 : W - 40;
  const titleCanvasH = topBandH - ((titleStyle === 'yellow_box') ? 60 : 30);
  const titleFontSize = Math.max(36, Math.floor(SQ / 13));

  const titlePng = path.join(workDir, 'title.png');
  renderTitlePng({
    text: title || ' ',
    width: titleCanvasW,
    height: titleCanvasH,
    fontSize: titleFontSize,
    outPath: titlePng,
    fg: titleFg,
    bg: titleBg,
    shadow: titleShadow,
    fontWeight: 'bold',
    maxCharsPerLine: 22,
  });
  jobLog.info(`✓ title.png rendered: ${titleCanvasW}x${titleCanvasH} (Pillow+Raqm+harfbuzz)`);

  // ---------- 2) Pre-render SPEAKER name as PNG ----------
  let speakerPng = null;
  if (speaker && speaker.trim()) {
    speakerPng = path.join(workDir, 'speaker.png');
    const spkFs = Math.max(26, Math.floor(SQ / 22));
    renderTitlePng({
      text: speaker.trim(),
      width: Math.floor(W * 0.7),
      height: Math.floor(bottomBandH * 0.9),
      fontSize: spkFs,
      outPath: speakerPng,
      fg: [255, 255, 255, 255],
      bg: [0, 0, 0, 0],
      shadow: [0, 0, 0, 150, 1, 1],
      fontWeight: 'bold',
      maxCharsPerLine: 30,
    });
    jobLog.info(`✓ speaker.png rendered`);
  }

  // ---------- 3) Build ffmpeg filter chain ----------
  const hasMic = !!speakerPng && fs.existsSync(MIC_PNG);

  // Inputs: 0=video, 1=title.png, [2=speaker.png, 3=mic.png]
  // v2.6: Robust seek strategy for partial-downloaded sources.
  //   - Input-side -ss for fast keyframe seek (cheap)
  //   - -copyts + -avoid_negative_ts make_zero so timestamps start at 0
  //   - -t after -i with output-side trim ensures correct duration even
  //     if the input file has weird PTS (common with --download-sections)
  // Use a slightly earlier seek to guarantee a keyframe is available, then
  // let the filter chain start at the requested moment. We rebase via
  // setpts in the filter chain (already PTS-STARTPTS in the bg layer).
  const seekStart = Math.max(0, start - 0.05);
  const inputs = [
    '-ss', ffTime(seekStart),
    '-noaccurate_seek',
    '-i', input,
    '-ss', '0',
    '-t', ffTime(duration),
  ];
  // Reorder: -i first so the second -ss is interpreted as input-time
  // adjustment after demuxer seek. Actually FFmpeg expects input-side -ss
  // BEFORE -i. So we use only input-side -ss and rely on filter trim.
  inputs.length = 0;
  inputs.push('-ss', ffTime(seekStart), '-i', input);
  inputs.push('-i', titlePng);
  if (speakerPng) inputs.push('-i', speakerPng);
  if (hasMic)     inputs.push('-i', MIC_PNG);

  let titleIdx   = 1;
  let speakerIdx = speakerPng ? 2 : null;
  let micIdx     = hasMic ? (speakerPng ? 3 : 2) : null;

  const videoChain = [];

  // a) Source: crop/fit to 1:1
  if (cropMode === 'crop') {
    videoChain.push(
      `[0:v]crop='min(iw,ih)':'min(iw,ih)':(iw-min(iw\\,ih))/2:(ih-min(iw\\,ih))/2,` +
      `scale=${SQ}:${SQ}:flags=lanczos,setsar=1[sq]`
    );
  } else {
    videoChain.push(
      `[0:v]scale=${SQ}:${SQ}:force_original_aspect_ratio=decrease,` +
      `pad=${SQ}:${SQ}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1[sq]`
    );
  }

  // b) Background canvas
  const dCeil = Math.max(1, Math.ceil(duration));
  if (titleStyle === 'gradient') {
    videoChain.push(
      `gradients=size=${W}x${H}:duration=${dCeil}:` +
      `c0=0x2a0845:c1=0x000000:` +
      `x0=${Math.floor(W/2)}:y0=0:x1=${Math.floor(W/2)}:y1=${H}:r=30,` +
      `trim=duration=${duration},setpts=PTS-STARTPTS[bg]`
    );
  } else {
    videoChain.push(
      `color=c=black:s=${W}x${H}:r=30:d=${dCeil},` +
      `trim=duration=${duration},setpts=PTS-STARTPTS[bg]`
    );
  }
  videoChain.push(`[bg][sq]overlay=0:${videoY}[base]`);

  let layer = '[base]';

  // c) Yellow box backdrop (yellow_box style only)
  if (titleStyle === 'yellow_box') {
    const bm = 24;
    const bx = bm, by = 24;
    const bw = W - 2 * bm;
    const bh = topBandH - 48;
    videoChain.push(
      `${layer}drawbox=x=${bx-3}:y=${by-3}:w=${bw+6}:h=${bh+6}:color=black:t=fill[bb1]`
    );
    videoChain.push(
      `[bb1]drawbox=x=${bx}:y=${by}:w=${bw}:h=${bh}:color=0xFFD700:t=fill[bb2]`
    );
    layer = '[bb2]';
  }

  // d) Speaker bar background
  if (speakerPng) {
    videoChain.push(
      `${layer}drawbox=x=0:y=${speakerBarY}:w=${W}:h=${bottomBandH}:color=0x111111:t=fill[sbg]`
    );
    layer = '[sbg]';
  }

  // e) Title PNG overlay (centered in top band)
  const titleX = Math.floor((W - titleCanvasW) / 2);
  const titleY = Math.floor((topBandH - titleCanvasH) / 2);
  videoChain.push(`${layer}[${titleIdx}:v]overlay=${titleX}:${titleY}:format=auto[lt]`);
  layer = '[lt]';

  // f) Mic + Speaker overlays (bottom band)
  if (speakerPng) {
    const spkFs = Math.max(26, Math.floor(SQ / 22));
    const micH  = Math.floor(spkFs * 1.5);
    // mic.png native aspect is preserved; use scale=W:-1
    const micW  = Math.floor(micH * 0.5);  // approx aspect

    // Pre-compute speaker PNG actual width by ffprobe? Use canvas width
    const spkCanvasW = Math.floor(W * 0.7);
    // Total group width = mic + gap + speaker (approx 60% of canvas)
    const groupW = micW + 14 + spkCanvasW;
    const groupX = Math.floor((W - groupW) / 2);
    const micX   = groupX;
    const micY   = speakerBarY + Math.floor((bottomBandH - micH) / 2);

    if (hasMic) {
      videoChain.push(`[${micIdx}:v]scale=-1:${micH}[micscaled]`);
      videoChain.push(`${layer}[micscaled]overlay=${micX}:${micY}:format=auto[lm]`);
      layer = '[lm]';
    }

    // Speaker PNG to right of mic, vertically centered in bottom band
    const spkX = hasMic ? (micX + micW + 14) : Math.floor((W - spkCanvasW) / 2);
    const spkCanvasH = Math.floor(bottomBandH * 0.9);
    const spkY = speakerBarY + Math.floor((bottomBandH - spkCanvasH) / 2);
    videoChain.push(`${layer}[${speakerIdx}:v]overlay=${spkX}:${spkY}:format=auto[v]`);
  } else {
    videoChain.push(`${layer}null[v]`);
  }

  const filterComplex = videoChain.join(';');

  const args = [
    '-hide_banner',
    '-loglevel', 'error',
    '-stats',
    '-y',
    ...inputs,
    '-filter_complex', filterComplex,
    '-map', '[v]',
    '-map', '0:a?',
    '-ss', '0.05',
    '-t', ffTime(duration),
    '-avoid_negative_ts', 'make_zero',
    '-fps_mode', 'cfr',
    '-c:v', 'libx264',
    '-preset', PRESET,
    '-crf', CRF,
    '-pix_fmt', 'yuv420p',
    '-r', '30',
    '-c:a', 'aac',
    '-b:a', '128k',
    '-ac', '2',
    '-ar', '44100',
    '-shortest',
    '-movflags', '+faststart',
    '-threads', THREADS,
    '-max_muxing_queue_size', '1024',
    output,
  ];

  jobLog.info(
    `ffmpeg start [ffmpeg-module=${FFMPEG_MODULE_VERSION}]: ` +
    `${path.basename(output)} | style=${titleStyle} | crop=${cropMode} | ` +
    `${duration.toFixed(1)}s | ${W}x${H} | engine=Pillow+Raqm+harfbuzz | preset=${PRESET}`
  );

  return new Promise((resolve, reject) => {
    const proc = spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] });
    if (jobId) trackProc(jobId, proc);
    let lastErr = '';
    proc.stdout.on('data', d => d.toString().split(/\r?\n/).forEach(l => l && jobLog.info(`ffmpeg> ${l}`)));
    proc.stderr.on('data', d => {
      const t = d.toString();
      lastErr += t;
      t.split(/\r?\n/).forEach(l => l && jobLog.info(`ffmpeg> ${l.trim()}`));
    });
    proc.on('error', reject);
    proc.on('close', code => {
      if (code === 0) {
        jobLog.info(`ffmpeg done: ${path.basename(output)}`);
        resolve(output);
      } else {
        reject(new Error(`ffmpeg exited ${code}: ${lastErr.slice(-500)}`));
      }
    });
  });
}

module.exports = { makeClip, FFMPEG_MODULE_VERSION, killJob };
