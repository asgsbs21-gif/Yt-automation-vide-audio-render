'use strict';

// =====================================================================
// YT Studio — Clipper Job Manager
//
// Inherits waz-clipper v2.6 job logic, plus:
//   • AbortController per job
//   • deleteJob now KILLS running yt-dlp/ffmpeg processes immediately
//   • Per-clip flag `aborted` so the clipping loop bails out at once
// =====================================================================

const { v4: uuid } = require('uuid');
const path = require('path');
const fs = require('fs');
const { logger } = require('../utils/logger');
const { parseRange } = require('../utils/timestamp');
const { downloadVideo, killJob: killYtdlpJob } = require('./ytdlp-clipper');
const { makeClip, killJob: killFfmpegJob } = require('./ffmpeg');

const OUTPUT_DIR = process.env.OUTPUT_DIR || '/app/data/output';
const TEMP_DIR   = process.env.TEMP_DIR   || '/tmp/waz';

const STORE_FILE = path.join(OUTPUT_DIR, '_jobs-clipper.json');
let jobs = {};
const aborted = new Set();   // jobIds that were deleted

function loadStore() {
  try {
    if (fs.existsSync(STORE_FILE)) jobs = JSON.parse(fs.readFileSync(STORE_FILE, 'utf8'));
  } catch (e) { logger.warn('Could not load clipper job store:', e.message); }
}
function saveStore() {
  try {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
    fs.writeFileSync(STORE_FILE, JSON.stringify(jobs, null, 2));
  } catch (_) {}
}
loadStore();

function sanitizeName(s) {
  return String(s || 'clip')
    .replace(/[\\/:"*?<>|\n\r\t]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80) || 'clip';
}

function normalizeUrl(url) {
  if (!url) return url;
  return String(url).trim().replace(/^(Https?|HTTPS?):/i, m => m.toLowerCase());
}

const VALID_STYLES = new Set(['yellow_box', 'gradient', 'centered']);
const VALID_CROPS  = new Set(['crop', 'fit']);

function createJob(payload) {
  const id = uuid().slice(0, 8);
  const defaultStyle = VALID_STYLES.has(payload.defaultStyle) ? payload.defaultStyle : 'centered';
  const cropMode     = VALID_CROPS.has(payload.cropMode) ? payload.cropMode : 'crop';
  const partial      = payload.partial !== false;

  const job = {
    id,
    type: 'clipper',
    url: normalizeUrl(payload.url),
    speaker: payload.speaker || '',
    defaultStyle,
    cropMode,
    partial,
    status: 'queued',
    createdAt: Date.now(),
    clips: payload.clips.map((c, i) => ({
      index: i,
      title: c.title || `Clip ${i + 1}`,
      range: c.range,
      style: VALID_STYLES.has(c.style) ? c.style : defaultStyle,
      status: 'pending',
      filename: null,
      error: null,
      driveFileId: null,
    })),
    sourcePath: null,
    error: null,
  };
  jobs[id] = job;
  saveStore();
  setImmediate(() => runJob(id));
  return job;
}

function checkAborted(id) {
  return aborted.has(id) || !jobs[id];
}

async function runJob(id) {
  const job = jobs[id];
  if (!job) return;
  const jl = logger.forJob(id);
  job.status = 'downloading';
  saveStore();

  try {
    jl.info(`📥 Source download starting: ${job.url} (partial=${job.partial})`);

    const clipRanges = job.clips.map(c => c.range);
    const dl = await downloadVideo(job.url, id, jl, {
      partial: job.partial,
      clipRanges,
    });

    if (checkAborted(id)) { jl.warn('Job aborted by user — stopping after download.'); return; }

    job.sourcePath = dl.sources[0] && dl.sources[0].sourcePath;
    jl.info(`✅ Download complete (mode=${dl.mode}); ${dl.sources.filter(s => s.sourcePath).length}/${dl.sources.length} sources ready`);

    job.status = 'clipping';
    saveStore();

    for (const clip of job.clips) {
      if (checkAborted(id)) { jl.warn('Job aborted — stopping clip loop.'); return; }
      try {
        const src = dl.sources[clip.index];
        if (!src || !src.sourcePath) {
          throw new Error(`Source download failed for this section: ${src && src.error ? src.error : 'unknown error'}`);
        }
        const { start: origStart, duration } = parseRange(clip.range);
        const localStart = Math.max(0, origStart - (src.sectionStart || 0));

        const safeTitle = sanitizeName(clip.title);
        const filename = `${id}__${String(clip.index + 1).padStart(2, '0')}__${safeTitle}.mp4`;
        const out = path.join(OUTPUT_DIR, filename);
        clip.status = 'rendering';
        saveStore();

        jl.info(`🎬 Clip ${clip.index + 1}: source=${path.basename(src.sourcePath)}, sectionStart=${(src.sectionStart||0).toFixed(2)}s, origStart=${origStart}s → localStart=${localStart.toFixed(2)}s, dur=${duration}s`);

        await makeClip({
          input: src.sourcePath,
          start: localStart,
          duration,
          title: clip.title,
          speaker: job.speaker,
          titleStyle: clip.style,
          cropMode: job.cropMode,
          output: out,
          workDir: path.join(TEMP_DIR, id),
          jobLog: jl,
          jobId: id,
        });

        if (checkAborted(id)) { jl.warn('Job aborted right after clip ' + (clip.index + 1)); return; }

        clip.filename = filename;
        clip.status = 'ready';
        saveStore();
        jl.info(`🎬 Clip ${clip.index + 1} ready: ${filename}`);
      } catch (e) {
        clip.status = 'failed';
        clip.error = e.message;
        jl.error(`❌ Clip ${clip.index + 1} failed:`, e.message);
        saveStore();
      }
    }

    if (!checkAborted(id)) {
      job.status = 'done';
      saveStore();
      jl.info(`🏁 Job done`);
    }
  } catch (e) {
    if (checkAborted(id)) {
      jl.warn(`Job aborted: ${e.message}`);
    } else {
      job.status = 'failed';
      job.error = e.message;
      jl.error('Job failed:', e);
      saveStore();
    }
  } finally {
    try {
      const dir = path.join(TEMP_DIR, id);
      if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
    } catch (_) {}
    aborted.delete(id);
  }
}

function getJob(id)  { return jobs[id] || null; }
function listJobs()  {
  return Object.values(jobs).sort((a, b) => b.createdAt - a.createdAt).slice(0, 50);
}

function deleteJob(id) {
  const j = jobs[id];
  if (!j) return false;

  // 1) Mark aborted so the loop bails out at next checkpoint
  aborted.add(id);

  // 2) Immediately kill any running yt-dlp / ffmpeg children
  const ytKilled = killYtdlpJob(id);
  const ffKilled = killFfmpegJob ? killFfmpegJob(id) : 0;
  if (ytKilled || ffKilled) {
    logger.info(`[job:${id}] killed ${ytKilled} yt-dlp + ${ffKilled} ffmpeg proc(s)`);
  }

  // 3) Delete output files for this job
  for (const c of j.clips) {
    if (c.filename) {
      try { fs.unlinkSync(path.join(OUTPUT_DIR, c.filename)); } catch (_) {}
    }
  }

  // 4) Clean temp work dir
  try {
    const dir = path.join(TEMP_DIR, id);
    if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
  } catch (_) {}

  delete jobs[id];
  saveStore();
  return true;
}

module.exports = { createJob, getJob, listJobs, deleteJob };
