#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Sub Burner Worker  —  called by Node.js as a subprocess.
Reads job config from --config <path>.json
Outputs JSON lines to stdout for progress/log streaming.
"""

import argparse
import json
import math
import os
import re
import subprocess
import sys
import time
import traceback
import urllib.request
import urllib.parse
from pathlib import Path

# ── stdout JSON emitters ───────────────────────────────────────────────────────

def emit(obj):
    print(json.dumps(obj, ensure_ascii=False), flush=True)

def log(level, msg):
    emit({'type': 'log', 'level': level, 'msg': str(msg)})

def info(msg):     log('info',  msg)
def warn(msg):     log('warn',  msg)
def err(msg):      log('error', msg)

def progress(pct, stage=''):
    emit({'type': 'progress', 'pct': int(pct), 'stage': stage})

# ── font / style data ──────────────────────────────────────────────────────────

FONTS_DIR = Path('/tmp/subburner_fonts')
FONTS_DIR.mkdir(parents=True, exist_ok=True)

FONTS = {
    '1': {
        'name': 'SolaimanLipi', 'family': 'SolaimanLipi',
        'file': 'SolaimanLipi.ttf',
        'url':  'https://raw.githubusercontent.com/shiftenterdev/bangla-font/master/SolaimanLipi.ttf',
    },
    '2': {
        'name': 'Kalpurush', 'family': 'Kalpurush',
        'file': 'kalpurush.ttf',
        'url':  'https://raw.githubusercontent.com/hmoazzem/bangla-fonts/master/kalpurush.ttf',
    },
    '3': {
        'name': 'Hind Siliguri', 'family': 'Hind Siliguri',
        'file': 'HindSiliguri-Regular.ttf',
        'url':  'https://github.com/google/fonts/raw/main/ofl/hindsiliguri/HindSiliguri-Regular.ttf',
    },
}

COLORS    = {'1': ('White','&H00FFFFFF'), '2': ('Warm White','&H00F2F7FF'),
             '3': ('Netflix Yellow','&H0000F8FF'), '4': ('Cyan','&H00FFFF00')}
POSITIONS = {'1': ('Bottom', 2), '2': ('Middle', 5), '3': ('Top', 8)}
SIZES     = {'1': ('Normal', 0.060), '2': ('Large', 0.072),
             '3': ('XL', 0.084), '4': ('XXL', 0.096)}

STYLE_PRESETS = {
    '1': {
        'name': 'Screenshot Boxed',
        'font_key': '1', 'color_key': '1', 'position_key': '1', 'size_key': '1',
        'bold': True, 'italic': False, 'border_style': 3, 'outline': 1, 'shadow': 0,
        'back_colour': '&H50000000', 'outline_colour': '&H00000000',
        'spacing': 0, 'margin_lr_ratio': 0.05, 'margin_v_ratio': 0.04, 'blur': 0,
        'size_ratio_916': 0.038, 'margin_lr_ratio_916': 0.04, 'margin_v_ratio_916': 0.06,
        'crop_169_font_size': 56,      # fixed font size in px for 9:16 mode
        'crop_169_margin_offset': 75,  # additional margin (bottom_black + offset)
    },
    '2': {
        'name': 'Netflix Clean',
        'font_key': '1', 'color_key': '1', 'position_key': '1', 'size_key': '1',
        'bold': True, 'italic': False, 'border_style': 1, 'outline': 2.5, 'shadow': 1.0,
        'back_colour': '&H00000000', 'outline_colour': '&H00000000',
        'spacing': 0, 'margin_lr_ratio': 0.05, 'margin_v_ratio': 0.04, 'blur': 0,
        'size_ratio_916': 0.038, 'margin_lr_ratio_916': 0.04, 'margin_v_ratio_916': 0.06,
        'crop_169_font_size': 52,
        'crop_169_margin_offset': 70,
    },
    '3': {
        'name': 'Big Mobile Box',
        'font_key': '1', 'color_key': '1', 'position_key': '1', 'size_key': '2',
        'bold': True, 'italic': False, 'border_style': 3, 'outline': 1, 'shadow': 0,
        'back_colour': '&H60000000', 'outline_colour': '&H00000000',
        'spacing': 0, 'margin_lr_ratio': 0.05, 'margin_v_ratio': 0.04, 'blur': 0,
        'size_ratio_916': 0.042, 'margin_lr_ratio_916': 0.04, 'margin_v_ratio_916': 0.06,
        'crop_169_font_size': 52,
        'crop_169_margin_offset': 85,
    },
}

# ── utilities ─────────────────────────────────────────────────────────────────

def download_bytes(url, timeout=60):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()

def ensure_font(font_key):
    meta = FONTS.get(font_key, FONTS['1'])
    path = FONTS_DIR / meta['file']
    if path.exists() and path.stat().st_size > 10000:
        info(f'Font ready: {meta["name"]}')
        return str(path)
    info(f'Downloading font: {meta["name"]} …')
    try:
        data = download_bytes(meta['url'], timeout=60)
        path.write_bytes(data)
        if path.stat().st_size <= 10000:
            raise RuntimeError('font too small after download')
        info(f'Font saved: {path}')
        return str(path)
    except Exception as e:
        warn(f'Font download failed: {e} — will fall back to system font')
        return ''

def esc_filter(p):
    return p.replace('\\', '\\\\').replace(':', '\\:').replace("'", "\\'").replace(',', '\\,')

def fmt_time(sec):
    if sec is None: return '?'
    sec = int(sec); h = sec // 3600; m = (sec % 3600) // 60; s = sec % 60
    if h: return f'{h}h {m}m {s}s'
    if m: return f'{m}m {s}s'
    return f'{s}s'

def strip_html_tags(text):
    return re.sub(r'<[^>]+>', '', text)

def to_ass_time(ts):
    ts = ts.strip().replace(',', '.')
    if re.fullmatch(r'\d+:\d+:\d+(?:\.\d+)?', ts):
        h, m, s = ts.split(':')
        sec = float(s)
        cs = int(round((sec - int(sec)) * 100))
        return f'{int(h)}:{int(m):02d}:{int(sec):02d}.{cs:02d}'
    return ts

# ── ASS builder ───────────────────────────────────────────────────────────────

def build_header(play_w, play_h, font_family, font_size, primary_colour,
                 align, margin_v, bold, italic, preset):
    bf  = -1 if bold   else 0
    itf = -1 if italic else 0
    margin_lr = max(20, int(round(play_w * preset.get('_margin_lr_ratio_active', preset['margin_lr_ratio']))))
    return (
        '[Script Info]\nTitle: SubBurner\nScriptType: v4.00+\n'
        f'PlayResX: {play_w}\nPlayResY: {play_h}\n'
        'ScaledBorderAndShadow: yes\nWrapStyle: 1\nYCbCr Matrix: TV.709\n\n'
        '[V4+ Styles]\n'
        'Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, '
        'OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, '
        'ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, '
        'Alignment, MarginL, MarginR, MarginV, Encoding\n'
        f'Style: Default,{font_family},{font_size},{primary_colour},&H0000FFFF,'
        f'{preset["outline_colour"]},{preset["back_colour"]},{bf},{itf},0,0,100,100,'
        f'{preset["spacing"]},0,{preset["border_style"]},{preset["outline"]},'
        f'{preset["shadow"]},{align},{margin_lr},{margin_lr},{margin_v},1\n\n'
        '[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n'
    )

def srt_text_to_ass(srt_text, ass_path, play_w, play_h, preset_key, crop_169=False):
    """Convert SRT text → ASS file. Returns the font_key used."""
    preset    = STYLE_PRESETS.get(preset_key, STYLE_PRESETS['1'])
    font_key  = preset['font_key']
    font_meta = FONTS.get(font_key, FONTS['1'])
    color_hex = COLORS[preset['color_key']][1]
    align     = POSITIONS[preset['position_key']][1]
    # Use 9:16 ratios when crop_169 is active
    if crop_169 and preset.get('size_ratio_916'):
        size_ratio    = preset['size_ratio_916']
        margin_lr_ratio = preset['margin_lr_ratio_916']
        margin_v_ratio  = preset['margin_v_ratio_916']
    else:
        size_ratio    = SIZES[preset['size_key']][1]
        margin_lr_ratio = preset['margin_lr_ratio']
        margin_v_ratio  = preset['margin_v_ratio']
    font_size = max(20, int(round(play_h * size_ratio)))
    if crop_169:
        # 1:1 centre-crop → pad to 9:16
        # Output canvas: width=play_w (the square side), height=play_w*16/9
        # FFmpeg scale step ensures both dims are even (trunc/2*2).
        padded_h = int(round(play_w * 16 / 9))
        padded_h = (padded_h // 2) * 2          # make even (matches FFmpeg trunc)
        play_w   = (play_w  // 2) * 2            # make even
        video_h_in_pad = play_w
        bottom_black = (padded_h - video_h_in_pad) // 2
        # Use preset-specific font size and margin offset
        font_size = preset.get('crop_169_font_size', 40)
        margin_v  = bottom_black + preset.get('crop_169_margin_offset', 70)
        # FIX: update BOTH play_w and play_h so ASS PlayResX/PlayResY
        # match the actual 9:16 canvas FFmpeg produces.
        play_h = padded_h
        # play_w stays as the square width (correct — canvas width = square side)
    else:
        margin_v = max(20, int(round(play_h * margin_v_ratio)))
    preset = dict(preset)
    preset['_margin_lr_ratio_active'] = margin_lr_ratio

    blocks    = re.split(r'\n\s*\n', srt_text.strip())
    dialogues = []
    for block in blocks:
        lines = [x.rstrip() for x in block.splitlines() if x.strip()]
        if len(lines) < 2: continue
        if re.fullmatch(r'\d+', lines[0]): lines = lines[1:]
        if not lines or '-->' not in lines[0]: continue
        start_str, end_str = [x.strip() for x in lines[0].split('-->', 1)]
        body = '\n'.join(lines[1:])
        body = strip_html_tags(body).replace('\r', '').replace('\n', r'\N').strip()
        if preset.get('blur', 0):
            body = '{\\blur' + str(preset['blur']) + '}' + body
        dialogues.append((to_ass_time(start_str), to_ass_time(end_str), body))

    header = build_header(
        play_w, play_h, font_meta['family'], font_size, color_hex,
        align, margin_v, preset['bold'], preset['italic'], preset
    )
    body_str = '\n'.join(
        f'Dialogue: 0,{s},{e},Default,,0,0,0,,{t}' for s, e, t in dialogues
    )
    Path(ass_path).write_text(header + body_str + '\n', encoding='utf-8')
    info(f'ASS ready — {len(dialogues)} subtitle lines')
    return font_key

# ── SRT clipping ──────────────────────────────────────────────────────────────

def parse_srt_time_to_seconds(ts):
    ts = ts.strip().replace(',', '.')
    parts = ts.split(':')
    if len(parts) == 3:
        return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
    return 0.0

def clip_srt(srt_text, start_sec, end_sec):
    """Return SRT text trimmed to [start_sec, end_sec], re-based to 0."""
    def sec_to_srt(t):
        t = max(0.0, t)
        h = int(t // 3600); m = int((t % 3600) // 60)
        s_ = int(t % 60);   ms = int(round((t - int(t)) * 1000))
        return f'{h:02d}:{m:02d}:{s_:02d},{ms:03d}'

    blocks = re.split(r'\n\s*\n', srt_text.strip())
    out = []; idx = 1
    for block in blocks:
        lines = [x.rstrip() for x in block.splitlines() if x.strip()]
        if len(lines) < 2: continue
        if re.fullmatch(r'\d+', lines[0]): lines = lines[1:]
        if not lines or '-->' not in lines[0]: continue
        ts, rest = lines[0], lines[1:]
        s_str, e_str = [x.strip() for x in ts.split('-->', 1)]
        s_sec = parse_srt_time_to_seconds(s_str)
        e_sec = parse_srt_time_to_seconds(e_str)
        if e_sec < start_sec or s_sec > end_sec: continue
        new_s = max(0.0, s_sec - start_sec)
        new_e = max(0.0, e_sec - start_sec)
        out.append(f'{idx}\n{sec_to_srt(new_s)} --> {sec_to_srt(new_e)}\n' + '\n'.join(rest))
        idx += 1
    return '\n\n'.join(out) + ('\n\n' if out else '')

# ── FFprobe ───────────────────────────────────────────────────────────────────

def ffprobe_meta(url, referer=''):
    headers_val = 'Accept: */*\r\n'
    if referer:
        headers_val += f'Referer: {referer}\r\nOrigin: {referer}\r\n'
    cmd = [
        'ffprobe', '-v', 'error',
        '-user_agent', 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
        '-headers', headers_val,
        '-print_format', 'json', '-show_streams', '-show_format', url,
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=45)
        if r.returncode != 0:
            return 1280, 720, None
        data = json.loads(r.stdout)
        vstream = next((s for s in data.get('streams', []) if s.get('codec_type') == 'video'), None)
        w   = int(vstream.get('width',  1280)) if vstream else 1280
        h   = int(vstream.get('height', 720))  if vstream else 720
        dur = float(data.get('format', {}).get('duration', 0) or 0) or None
        return w, h, dur
    except Exception as e:
        warn(f'ffprobe failed: {e}')
        return 1280, 720, None

# ── FFmpeg runner ─────────────────────────────────────────────────────────────

def parse_ffmpeg_time(line):
    m = re.search(r'time=(\d+):(\d+):(\d+(?:\.\d+)?)', line)
    if not m: return None
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))

def run_ffmpeg(cmd, duration=None, stage='render'):
    info(f'FFmpeg: {" ".join(cmd[:8])} …')
    p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, bufsize=1)
    last_pct = -1
    for line in p.stderr:
        line = line.rstrip()
        if not line: continue
        if 'time=' in line and duration:
            cur = parse_ffmpeg_time(line)
            if cur is not None:
                pct = min(99, int(cur / duration * 100))
                if pct != last_pct:
                    progress(pct, stage)
                    last_pct = pct
        if any(x in line.lower() for x in ['error', 'failed', 'invalid', 'no such file']):
            warn(f'FFmpeg stderr: {line}')
    p.wait()
    return p.returncode

# ── Video filter builder ──────────────────────────────────────────────────────

def render_title_png(title_text, out_png, video_w=720, crop_169=False):
    """Render Bengali title to PNG using Pillow+libraqm. Returns True on success."""
    try:
        from PIL import Image, ImageDraw, ImageFont
        import unicodedata
        title_text = unicodedata.normalize('NFC', title_text)

        # Pick best available font
        font_candidates = [
            str(FONTS_DIR / 'SolaimanLipi.ttf'),
            str(FONTS_DIR / 'kalpurush.ttf'),
            str(FONTS_DIR / 'HindSiliguri-Regular.ttf'),
        ]
        font_path = next((f for f in font_candidates if os.path.exists(f)), None)

        # Canvas size: full width, ~12% of video height for title bar
        canvas_w = video_w
        canvas_h = int(video_w * (0.18 if crop_169 else 0.13))
        font_size = int(canvas_h * 0.38)
        font_size = max(24, min(font_size, 64))

        img  = Image.new('RGBA', (canvas_w, canvas_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        try:
            font = ImageFont.truetype(font_path, font_size) if font_path else ImageFont.load_default()
        except Exception:
            font = ImageFont.load_default()

        # Word-wrap
        words = title_text.split()
        lines, cur = [], ''
        for w in words:
            test = (cur + ' ' + w).strip()
            try:
                tw = draw.textlength(test, font=font)
            except Exception:
                tw = len(test) * font_size * 0.6
            if tw > canvas_w - 40 and cur:
                lines.append(cur)
                cur = w
            else:
                cur = test
        if cur:
            lines.append(cur)
        lines = lines[:3]  # max 3 lines

        # Measure total height
        try:
            lh = draw.textbbox((0,0), 'Ay', font=font)[3] + 6
        except Exception:
            lh = font_size + 6
        total_h = lh * len(lines)
        y0 = (canvas_h - total_h) // 2

        # Semi-transparent dark background bar
        draw.rectangle([(0, 0), (canvas_w, canvas_h)], fill=(0, 0, 0, 170))

        # White text with shadow — centered
        for i, line in enumerate(lines):
            try:
                tw = draw.textlength(line, font=font)
            except Exception:
                tw = len(line) * font_size * 0.6
            x = (canvas_w - tw) // 2
            y = y0 + i * lh
            # shadow
            draw.text((x+2, y+2), line, font=font, fill=(0, 0, 0, 200))
            # main text
            draw.text((x, y), line, font=font, fill=(255, 255, 255, 255))

        img.save(out_png, 'PNG')
        return True
    except Exception as e:
        warn(f'Title PNG render failed (Pillow): {e}')
        return False


def build_vf(ass_path, crop_169, title_png=None, video_w=720, video_h=1280):
    """Return (-vf filterstring, extra_inputs).
    If title_png given, uses -filter_complex to overlay title at top.
    Otherwise returns simple -vf string (no extra inputs needed).
    """
    esc_ass   = esc_filter(str(ass_path))
    esc_fonts = esc_filter(str(FONTS_DIR))
    sub_filter = f"ass='{esc_ass}':fontsdir='{esc_fonts}'"

    if crop_169:
        crop  = "crop='min(iw,ih)':'min(iw,ih)'"
        pad   = "pad='iw':'trunc(iw*16/9/2)*2':'0':'(oh-ih)/2'"
        scale = "scale='trunc(iw/2)*2':'trunc(ih/2)*2'"
        base_vf = f"{crop},{pad},{scale},{sub_filter}"
        out_w = (video_w // 2) * 2
        out_h = (int(round(video_w * 16 / 9)) // 2) * 2
    else:
        base_vf = sub_filter
        out_w, out_h = video_w, video_h

    if not title_png or not os.path.exists(title_png):
        return 'simple', base_vf, []

    # Title bar height matches what render_title_png produced
    title_h = int(out_w * (0.18 if crop_169 else 0.13))
    # Place title just below top edge with small padding
    title_y = int(out_h * 0.04)

    # Use filter_complex: [0:v] base processing → [base]; overlay [1:v] title PNG
    if crop_169:
        fc = (
            f"[0:v]{crop},{pad},{scale},{sub_filter}[base];"
            f"[1:v]scale={out_w}:{title_h}[title];"
            f"[base][title]overlay=0:{title_y}[v]"
        )
    else:
        fc = (
            f"[0:v]{sub_filter}[base];"
            f"[1:v]scale={out_w}:{title_h}[title];"
            f"[base][title]overlay=0:{title_y}[v]"
        )
    return 'complex', fc, ['-i', title_png]

# ── Render helpers ────────────────────────────────────────────────────────────

def make_headers_val(referer):
    val = 'Accept: */*\r\n'
    if referer:
        val += f'Referer: {referer}\r\nOrigin: {referer}\r\n'
    return val

def render_full(video_url, referer, ass_path, out_path, duration, crop_169, title_png=None, video_w=720, video_h=1280):
    proxy = os.environ.get('FFMPEG_HTTP_PROXY', '')
    proxy_args = ['-http_proxy', proxy] if proxy else []
    mode, vf_val, extra_inputs = build_vf(ass_path, crop_169, title_png, video_w, video_h)
    base_args = [
        'ffmpeg', '-y',
        '-user_agent', 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
        '-headers', make_headers_val(referer),
        *proxy_args,
        '-i', video_url,
        *extra_inputs,
    ]
    if mode == 'complex':
        vf_args = ['-filter_complex', vf_val, '-map', '[v]', '-map', '0:a?']
    else:
        vf_args = ['-vf', vf_val]
    cmd = [
        *base_args, *vf_args,
        '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '22',
        '-c:a', 'aac', '-b:a', '128k',
        '-movflags', '+faststart',
        out_path,
    ]
    return run_ffmpeg(cmd, duration, 'render')

def render_clip(video_url, referer, ass_path, out_path, start_sec, clip_dur, crop_169, title_png=None, video_w=720, video_h=1280):
    proxy = os.environ.get('FFMPEG_HTTP_PROXY', '')
    proxy_args = ['-http_proxy', proxy] if proxy else []
    mode, vf_val, extra_inputs = build_vf(ass_path, crop_169, title_png, video_w, video_h)
    base_args = [
        'ffmpeg', '-y',
        '-user_agent', 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
        '-headers', make_headers_val(referer),
        *proxy_args,
        '-ss', str(start_sec),
        '-i', video_url,
        '-t', str(clip_dur),
        *extra_inputs,
    ]
    if mode == 'complex':
        vf_args = ['-filter_complex', vf_val, '-map', '[v]', '-map', '0:a?']
    else:
        vf_args = ['-vf', vf_val]
    cmd = [
        *base_args, *vf_args,
        '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '22',
        '-c:a', 'aac', '-b:a', '128k',
        '-movflags', '+faststart',
        out_path,
    ]
    return run_ffmpeg(cmd, clip_dur, 'clip')

# ── Upload helpers ────────────────────────────────────────────────────────────

def _multipart_upload(url, fields, file_field, file_path, timeout=300):
    """Simple multipart/form-data upload using stdlib only."""
    boundary = b'----SubBurnerBoundary7734'
    parts = bytearray()
    for name, value in fields.items():
        parts += (
            b'--' + boundary + b'\r\n'
            b'Content-Disposition: form-data; name="' + name.encode() + b'"\r\n\r\n'
            + str(value).encode() + b'\r\n'
        )
    fname = os.path.basename(file_path).encode()
    with open(file_path, 'rb') as fh:
        file_data = fh.read()
    parts += (
        b'--' + boundary + b'\r\n'
        b'Content-Disposition: form-data; name="' + file_field.encode() + b'"; filename="' + fname + b'"\r\n'
        b'Content-Type: video/mp4\r\n\r\n'
        + file_data + b'\r\n'
        + b'--' + boundary + b'--\r\n'
    )
    body = bytes(parts)
    req = urllib.request.Request(url, data=body, method='POST')
    req.add_header('Content-Type', f'multipart/form-data; boundary={boundary.decode()}')
    req.add_header('Content-Length', str(len(body)))
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode())

def upload_telegram(file_path, title, bot_token, chat_id):
    size_mb = round(os.path.getsize(file_path) / 1048576, 1)
    info(f'Uploading to Telegram ({size_mb} MB) …')
    if size_mb > 49:
        warn('File >49 MB — Telegram Bot API limit is 50 MB. Upload may fail.')
    url = f'https://api.telegram.org/bot{bot_token}/sendVideo'
    try:
        result = _multipart_upload(
            url,
            {'chat_id': str(chat_id), 'caption': f'**{title}**', 'supports_streaming': 'true'},
            'video', file_path
        )
        if result.get('ok'):
            msg = result['result']
            mid = msg.get('message_id', '')
            cid = str(chat_id).replace('-100', '')
            link = f'https://t.me/c/{cid}/{mid}' if str(chat_id).startswith('-100') else None
            info(f'Telegram OK — message_id={mid}')
            return link
        else:
            err(f'Telegram API error: {result.get("description", "unknown")}')
            return None
    except Exception as e:
        err(f'Telegram upload failed: {e}')
        return None

def upload_facebook(file_path, title, page_token, page_id):
    size_mb = round(os.path.getsize(file_path) / 1048576, 1)
    info(f'Uploading to Facebook Page ({size_mb} MB) …')
    url = f'https://graph.facebook.com/v19.0/{page_id}/videos'
    try:
        result = _multipart_upload(
            url,
            {'access_token': page_token, 'title': title, 'published': 'true'},
            'source', file_path
        )
        vid_id = result.get('id')
        if vid_id:
            info(f'Facebook OK — video_id={vid_id}')
            return f'https://www.facebook.com/video/{vid_id}'
        else:
            err(f'Facebook error: {result}')
            return None
    except Exception as e:
        err(f'Facebook upload failed: {e}')
        return None

def upload_youtube(file_path, title, access_token):
    size_mb = round(os.path.getsize(file_path) / 1048576, 1)
    info(f'Uploading to YouTube ({size_mb} MB) …')
    file_size = os.path.getsize(file_path)
    meta = json.dumps({
        'snippet': {'title': title, 'description': '', 'categoryId': '22'},
        'status': {'privacyStatus': 'private'},
    })
    init_url = 'https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status'
    req = urllib.request.Request(init_url, data=meta.encode(), method='POST')
    req.add_header('Authorization', f'Bearer {access_token}')
    req.add_header('Content-Type', 'application/json; charset=UTF-8')
    req.add_header('X-Upload-Content-Type', 'video/mp4')
    req.add_header('X-Upload-Content-Length', str(file_size))
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            upload_url = resp.headers.get('Location')
    except Exception as e:
        err(f'YouTube init failed: {e}')
        return None
    if not upload_url:
        err('No upload URL returned from YouTube')
        return None
    with open(file_path, 'rb') as fh:
        data = fh.read()
    req2 = urllib.request.Request(upload_url, data=data, method='PUT')
    req2.add_header('Content-Type', 'video/mp4')
    req2.add_header('Content-Length', str(file_size))
    try:
        with urllib.request.urlopen(req2, timeout=600) as resp:
            result = json.loads(resp.read().decode())
            vid_id = result.get('id')
            if vid_id:
                info(f'YouTube OK — video_id={vid_id}')
                return f'https://youtu.be/{vid_id}'
            else:
                err(f'YouTube response: {result}')
                return None
    except Exception as e:
        err(f'YouTube upload failed: {e}')
        return None

def do_uploads(file_path, title, uploads_cfg):
    links = {}
    tg = uploads_cfg.get('telegram', {})
    if tg.get('enabled') and tg.get('bot_token') and tg.get('chat_id'):
        links['telegram'] = upload_telegram(file_path, title, tg['bot_token'], tg['chat_id'])
    fb = uploads_cfg.get('facebook', {})
    if fb.get('enabled') and fb.get('page_token') and fb.get('page_id'):
        links['facebook'] = upload_facebook(file_path, title, fb['page_token'], fb['page_id'])
    yt = uploads_cfg.get('youtube', {})
    if yt.get('enabled') and yt.get('access_token'):
        links['youtube'] = upload_youtube(file_path, title, yt['access_token'])
    return links

# ── timestamp parser ──────────────────────────────────────────────────────────

def parse_ts(ts):
    """HH:MM:SS or MM:SS or seconds float."""
    ts = str(ts).strip()
    parts = ts.split(':')
    if len(parts) == 3:
        return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
    if len(parts) == 2:
        return int(parts[0]) * 60 + float(parts[1])
    return float(ts)

# ── main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True, help='Path to JSON job config')
    args = parser.parse_args()

    with open(args.config, encoding='utf-8') as fh:
        cfg = json.load(fh)

    mode        = cfg.get('mode', 'full')
    video_url   = cfg['video_url']
    referer     = cfg.get('referer', '')
    srt_path    = cfg['srt_path']
    preset_key  = str(cfg.get('preset', '1'))
    crop_169    = bool(cfg.get('crop_169', False))
    output_dir  = cfg['output_dir']
    job_id      = cfg['job_id']
    title       = cfg.get('title', 'SubBurner Video')
    uploads_cfg = cfg.get('uploads', {})
    clips       = cfg.get('clips', [])

    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # Load SRT
    info('Loading subtitle …')
    srt_text = Path(srt_path).read_text(encoding='utf-8', errors='replace')
    count = sum(1 for ln in srt_text.splitlines() if '-->' in ln)
    info(f'SRT loaded: {count} entries')

    # Probe video
    info('Probing video …')
    play_w, play_h, duration = ffprobe_meta(video_url, referer)
    info(f'Video: {play_w}x{play_h}, duration={fmt_time(duration)}')

    # Ensure font
    preset = STYLE_PRESETS.get(preset_key, STYLE_PRESETS['1'])
    ensure_font(preset['font_key'])

    if mode == 'full':
        # ── Full Render ──────────────────────────────────────────────────────
        info(f'=== Full Render | preset={preset["name"]} | crop_169={crop_169} ===')
        ass_path = os.path.join(output_dir, 'subtitle.ass')
        srt_text_to_ass(srt_text, ass_path, play_w, play_h, preset_key, crop_169=crop_169)
        out_path = os.path.join(output_dir, f'{job_id}_output.mp4')

        # Title overlay PNG
        title_png = None
        if title and title.strip() and title.strip() != 'SubBurner Video':
            title_png = os.path.join(output_dir, 'title.png')
            ok = render_title_png(title.strip(), title_png, video_w=play_w, crop_169=crop_169)
            if ok:
                info(f'✓ Title PNG rendered: {title.strip()}')
            else:
                title_png = None

        info('Starting FFmpeg …')
        rc = render_full(video_url, referer, ass_path, out_path, duration, crop_169,
                         title_png=title_png, video_w=play_w, video_h=play_h)
        if rc != 0 or not os.path.exists(out_path):
            err('FFmpeg render failed (non-zero exit)')
            emit({'type': 'error', 'msg': 'FFmpeg render failed'})
            return
        size_mb = round(os.path.getsize(out_path) / 1048576, 1)
        info(f'Render done: {size_mb} MB')
        progress(95, 'render_done')
        info('Starting uploads …')
        links = do_uploads(out_path, title, uploads_cfg)
        progress(100, 'done')
        emit({'type': 'done', 'outputs': [{'file': os.path.basename(out_path), 'links': links}]})

    elif mode == 'clip':
        # ── Clip Mode ────────────────────────────────────────────────────────
        total = len(clips)
        info(f'=== Clip Mode: {total} clips | preset={preset["name"]} | crop_169={crop_169} ===')
        results = []
        for i, clip in enumerate(clips):
            clip_title  = clip.get('title', f'Clip {i + 1}')
            start_sec   = parse_ts(clip['start'])
            end_sec     = parse_ts(clip['end'])
            clip_dur    = max(1.0, end_sec - start_sec)
            info(f'--- Clip {i+1}/{total}: "{clip_title}" {clip["start"]}→{clip["end"]} ({fmt_time(clip_dur)}) ---')
            emit({'type': 'clip_start', 'index': i, 'title': clip_title})

            # Trim SRT
            clipped_srt  = clip_srt(srt_text, start_sec, end_sec)
            clip_srt_path = os.path.join(output_dir, f'clip_{i+1:02d}.srt')
            Path(clip_srt_path).write_text(clipped_srt, encoding='utf-8')

            # Build ASS for this clip
            clip_ass_path = os.path.join(output_dir, f'clip_{i+1:02d}.ass')
            srt_text_to_ass(clipped_srt, clip_ass_path, play_w, play_h, preset_key, crop_169=crop_169)

            # Title PNG overlay
            clip_title_png = None
            if clip_title and clip_title.strip():
                clip_title_png = os.path.join(output_dir, f'clip_{i+1:02d}_title.png')
                ok = render_title_png(clip_title.strip(), clip_title_png, video_w=play_w, crop_169=crop_169)
                if ok:
                    info(f'\u2713 Title PNG: {clip_title.strip()}')
                else:
                    clip_title_png = None

            # Render
            safe = re.sub(r'[\\/:\"*?<>|\n\r\t]', ' ', clip_title).strip()[:60] or f'clip{i+1}'
            out_name = f'{job_id}_clip{i+1:02d}_{safe}.mp4'
            out_path = os.path.join(output_dir, out_name)
            rc = render_clip(video_url, referer, clip_ass_path, out_path, start_sec, clip_dur, crop_169,
                             title_png=clip_title_png, video_w=play_w, video_h=play_h)

            if rc != 0 or not os.path.exists(out_path):
                err(f'Clip {i+1} render failed')
                results.append({'clip': i + 1, 'title': clip_title, 'error': 'render failed', 'file': None})
                emit({'type': 'clip_done', 'index': i, 'status': 'failed', 'title': clip_title})
                continue

            size_mb = round(os.path.getsize(out_path) / 1048576, 1)
            info(f'Clip {i+1} rendered: {size_mb} MB')
            base_pct = int((i + 1) / total * 85)
            progress(base_pct, f'clip_{i+1}_rendered')

            # Upload
            links = do_uploads(out_path, clip_title, uploads_cfg)
            results.append({'clip': i + 1, 'title': clip_title, 'file': out_name, 'links': links})
            emit({'type': 'clip_done', 'index': i, 'status': 'ready',
                  'title': clip_title, 'file': out_name, 'links': links})
            progress(base_pct + 5, f'clip_{i+1}_uploaded')

        progress(100, 'done')
        emit({'type': 'done', 'outputs': results})

    else:
        err(f'Unknown mode: {mode}')
        emit({'type': 'error', 'msg': f'Unknown mode: {mode}'})

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        err(f'Fatal: {e}')
        err(traceback.format_exc())
        emit({'type': 'error', 'msg': str(e)})
        sys.exit(1)